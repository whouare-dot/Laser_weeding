﻿namespace Demo
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.axIMCAXCanvas1 = new AximcactivexLib.AxIMCAXCanvas();
            this.axIMCAXMark1 = new AximcactivexLib.AxIMCAXMark();
            this.axIMCAXEdit1 = new AximcactivexLib.AxIMCAXEdit();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.axIMCAXCanvas1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.axIMCAXMark1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.axIMCAXEdit1)).BeginInit();
            this.SuspendLayout();
            // 
            // axIMCAXCanvas1
            // 
            this.axIMCAXCanvas1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)));
            this.axIMCAXCanvas1.Enabled = true;
            this.axIMCAXCanvas1.Location = new System.Drawing.Point(12, 12);
            this.axIMCAXCanvas1.Name = "axIMCAXCanvas1";
            this.axIMCAXCanvas1.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axIMCAXCanvas1.OcxState")));
            this.axIMCAXCanvas1.Size = new System.Drawing.Size(547, 501);
            this.axIMCAXCanvas1.TabIndex = 0;
            // 
            // axIMCAXMark1
            // 
            this.axIMCAXMark1.Enabled = true;
            this.axIMCAXMark1.Location = new System.Drawing.Point(463, 474);
            this.axIMCAXMark1.Name = "axIMCAXMark1";
            this.axIMCAXMark1.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axIMCAXMark1.OcxState")));
            this.axIMCAXMark1.Size = new System.Drawing.Size(75, 23);
            this.axIMCAXMark1.TabIndex = 1;
            // 
            // axIMCAXEdit1
            // 
            this.axIMCAXEdit1.Enabled = true;
            this.axIMCAXEdit1.Location = new System.Drawing.Point(463, 448);
            this.axIMCAXEdit1.Name = "axIMCAXEdit1";
            this.axIMCAXEdit1.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axIMCAXEdit1.OcxState")));
            this.axIMCAXEdit1.Size = new System.Drawing.Size(75, 23);
            this.axIMCAXEdit1.TabIndex = 2;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(575, 12);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(102, 23);
            this.button1.TabIndex = 3;
            this.button1.Text = "Init";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(575, 58);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(102, 23);
            this.button2.TabIndex = 4;
            this.button2.Text = "CreateNew";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(575, 87);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(102, 23);
            this.button3.TabIndex = 5;
            this.button3.Text = "LoadFile";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(575, 144);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(102, 23);
            this.button4.TabIndex = 6;
            this.button4.Text = "AddText";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(575, 176);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(102, 23);
            this.button5.TabIndex = 7;
            this.button5.Text = "AddRect";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(575, 431);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(102, 23);
            this.button6.TabIndex = 8;
            this.button6.Text = "StartMark";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(575, 460);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(102, 23);
            this.button7.TabIndex = 9;
            this.button7.Text = "GetMarkStatus";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(575, 489);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(102, 23);
            this.button8.TabIndex = 10;
            this.button8.Text = "StopMark";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(575, 367);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 12);
            this.label1.TabIndex = 11;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(700, 525);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.axIMCAXCanvas1);
            this.Controls.Add(this.axIMCAXEdit1);
            this.Controls.Add(this.axIMCAXMark1);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.axIMCAXCanvas1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.axIMCAXMark1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.axIMCAXEdit1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private AximcactivexLib.AxIMCAXCanvas axIMCAXCanvas1;
        private AximcactivexLib.AxIMCAXMark axIMCAXMark1;
        private AximcactivexLib.AxIMCAXEdit axIMCAXEdit1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Label label1;
    }
}

