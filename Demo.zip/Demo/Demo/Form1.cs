﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using AximcactivexLib;

namespace Demo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //实际项目中需要添加返回值的判断
            int iRet = 0;

            //控件初始化
            iRet = axIMCAXMark1.Initial(1);
            iRet = axIMCAXCanvas1.Initial(1);
            iRet = axIMCAXEdit1.Initial();

            //创建一个空的文档
            iRet = axIMCAXMark1.CreateDocument();

            //设置成活动文档
            axIMCAXMark1.SetActiveDocument(iRet);
            axIMCAXCanvas1.SetActiveDocument(iRet);
            axIMCAXEdit1.SetActiveDocument(iRet);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //实际项目中需要添加返回值的判断

            //添加一个图层
            axIMCAXEdit1.AddLayer(("layer1"));
        }

        private void button3_Click(object sender, EventArgs e)
        {
            //实际项目中需要添加返回值的判断

            //打开文档
            int iRet = axIMCAXMark1.LoadFile(("c:\\Test.nmk"));

            //刷新界面
            axIMCAXCanvas1.UpdateCanvas();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            //实际项目中需要添加返回值的判断

            //添加一个OBJTEXT到文档
            axIMCAXMark1.AddText(("imc mfc demo"), 40, 40, (""), (""));

            //刷新界面
            axIMCAXCanvas1.UpdateCanvas();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            //实际项目中需要添加返回值的判断

            //添加一个OBJRECT到文档
            axIMCAXEdit1.AddRect(40, 40, 20 + 10, 20 + 10, ("layer1"), ("objRect"));

            //刷新界面
            axIMCAXCanvas1.UpdateCanvas();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            //实际项目中需要添加返回值的判断
	        int iRet = 0;
	        iRet = axIMCAXMark1.MarkStandBy();
            iRet = axIMCAXMark1.StartMarking(2);
        }

        private void button8_Click(object sender, EventArgs e)
        {
            //实际项目中需要添加返回值的判断
            int iRet = 0;
            iRet = axIMCAXMark1.StopMarking();
            iRet = axIMCAXMark1.MarkShutdown();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            //实际项目中需要添加返回值的判断
            long markTime = axIMCAXMark1.GetMarkTime() / 1000;
            long markCounts = axIMCAXMark1.GetMarkCounts();

            label1.Text = "markTime:" + markTime.ToString() + "\nmarkCounts:" + markCounts.ToString();
        }
    }
}
